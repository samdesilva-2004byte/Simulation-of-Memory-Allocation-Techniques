"""UI module for Memory Allocation Simulator"""
