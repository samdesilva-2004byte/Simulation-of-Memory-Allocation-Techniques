"""Backend module for Memory Allocation Simulator"""
