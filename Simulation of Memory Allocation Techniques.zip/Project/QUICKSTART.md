# 🚀 QUICK START GUIDE

## Memory Allocation Simulator - Get Started in 2 Minutes!

### Option 1: Run the GUI (Recommended) 🎨

```bash
cd S:\Edu\BTIT\OS\Project
python main.py
```

This opens an interactive desktop application where you can:
- Select allocation strategy (First/Best/Worst Fit)
- Allocate and deallocate processes
- Watch memory visualization update in real-time
- Analyze fragmentation statistics
- Generate detailed reports

### Option 2: Run the Demo 📊

```bash
python demo.py
```

This shows automated examples of all three strategies with console output.

### Option 3: Run Tests ✅

```bash
python tests.py
```

This verifies all functionality is working correctly (8 tests, all should pass).

---

## What You Can Do

### In the GUI:
1. **Select Strategy**: Choose First Fit, Best Fit, or Worst Fit
2. **Enter Size**: Type a process size (e.g., 100)
3. **Click Allocate**: Watch memory get allocated
4. **Select Process**: Click a process in the table
5. **Click Deallocate**: Free that memory
6. **View Reports**: See fragmentation analysis
7. **Reset**: Start over with fresh memory

### Key Features:
- 🎯 Real-time memory visualization
- 📊 Live statistics display
- 📈 Fragmentation analysis
- 🔄 Process management
- 📋 Detailed reports
- 🎨 Color-coded blocks

---

## Understanding the Display

```
┌──────────────────────┐
│   Strategy Selection  │  Choose allocation method
├──────────────────────┤
│  Process Controls    │  Allocate/Random/Reset
├──────────────────────┤
│  Memory Visualization│  See blocks with colors
├──────────────────────┤
│   Statistics         │  Usage & fragmentation
├──────────────────────┤
│  Process List        │  All allocated processes
├──────────────────────┤
│  Analysis Report     │  Detailed metrics
└──────────────────────┘
```

---

## Common Tasks

### Allocate Memory
1. Enter size (e.g., "150")
2. Click "Allocate"
3. See P1, P2, P3... added to list

### Free Memory
1. Select process from table
2. Click "Deallocate"
3. See process removed and merged

### Compare Strategies
1. Reset memory
2. Use First Fit with: 100, 150, 200
3. Reset memory
4. Use Best Fit with same sizes
5. Compare fragmentation %

### Check Fragmentation
1. Allocate several processes
2. Deallocate some (creating gaps)
3. Click "Generate Report"
4. Note the fragmentation %

---

## What is Happening?

### First Fit
Allocates in the **first available block**
- Fast ⚡
- May be wasteful

### Best Fit
Allocates in the **smallest exact fit**
- Better space usage
- May be slower

### Worst Fit
Allocates in the **largest block**
- Tries to reduce fragmentation
- More complex

---

## Understanding Fragmentation

**External Fragmentation**: How scattered is the free space?
- 0% = All free space is contiguous
- 100% = Free space is completely fragmented

**Memory Utilization**: How much memory is used?
- 50% = Half of memory is allocated
- 100% = All memory is allocated

---

## Files in Project

```
main.py           ← Run this for GUI
demo.py           ← Run for demos
tests.py          ← Run for tests
README.md         ← Full documentation
USERGUIDE.md      ← Detailed instructions
FEATURES.md       ← Complete features list
COMPLETION.md     ← Project checklist
```

---

## Troubleshooting

❌ **Application won't start**
- Make sure you're in the project directory
- Check Python version: `python --version` (need 3.6+)

❌ **Nothing displays**
- Resize the window
- Click "Reset Memory"

❌ **Can't allocate memory**
- Check if memory is full
- Try smaller size
- Click "Reset Memory"

❌ **Tests fail to run**
- Make sure you're in project directory
- Check backend/ and ui/ folders exist
- Verify Python is installed correctly

---

## 📚 Learn More

- **README.md** - Technical details & algorithms
- **USERGUIDE.md** - Step-by-step tutorials
- **FEATURES.md** - Complete specifications
- **Code comments** - Explanations in files

---

## 🎯 Examples

### Example 1: Create Fragmentation
```
1. Allocate: 100
2. Allocate: 100
3. Allocate: 100
4. Deallocate: P2
→ Now you have gaps!
```

### Example 2: Fill Memory
```
Keep clicking "Random Allocate"
until you get "No sufficient memory"
error → Your memory is full!
```

### Example 3: Compare Strategies
```
Same sequence with First/Best/Worst
Watch fragmentation % differences
-Note which handles it better
```

---

## 💡 Cool Things to Try

1. **Watch fragmentation build** - Allocate, deallocate, repeat
2. **Find the limit** - How many processes fit?
3. **Generate reports** - See detailed statistics
4. **Compare strategies** - With identical sequences
5. **Break the system** - Try to allocate too much
6. **Merge blocks** - See free blocks combine
7. **View address scale** - Understand memory layout

---

## Time Required

- **First run**: 30 seconds
- **Basic demo**: 2 minutes
- **Full exploration**: 10-15 minutes
- **Understanding concepts**: 30-60 minutes

---

## System Requirements

✅ Python 3.6+  
✅ Windows, Linux, or macOS  
✅ ~1 MB disk space  
✅ ~250 MB RAM  

That's it! No additional installations needed.

---

## Need Help?

1. **How to use?** → Check USERGUIDE.md
2. **What's included?** → Check FEATURES.md
3. **Technical details?** → Check README.md
4. **Verify it works?** → Run tests.py
5. **See examples?** → Run demo.py

---

## 🎓 Learning Path

```
1. Run main.py (2 min)
   ↓
2. Try basic allocation (3 min)
   ↓
3. Watch this guide (2 min)
   ↓
4. Read USERGUIDE.md (10 min)
   ↓
5. Complete tutorials (15 min)
   ↓
6. Read FEATURES.md (10 min)
   ↓
7. Experiment freely! (∞)
```

---

## That's It! 🎉

You're now ready to explore memory allocation concepts with a powerful simulator.

**Start with:**
```bash
python main.py
```

**Have fun learning!** 🚀

---

*For detailed documentation, see README.md or USERGUIDE.md*
